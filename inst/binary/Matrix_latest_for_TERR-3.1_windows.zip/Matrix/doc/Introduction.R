### R code from vignette source 'Introduction.Rnw'

###################################################
### code chunk number 1: preliminaries
###################################################
options(width=75)


